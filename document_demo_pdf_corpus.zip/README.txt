Document Management Demo PDF Corpus
Generated 100 PDFs for upload, OpenSearch indexing, semantic search, and RAG validation.
Use manifest.csv for metadata review and expected_search_and_rag_queries.csv for test prompts.
Key demo files include vacation policy, remote work policy, invoice 1001, Alpha contract, incident response, and Project Phoenix.
